package insa.model;

public class EmpDto {
	/* empinfo */
	private int emp_no, jik_no, empinfo_year, empifo_pass;
	private String jik_name, empinfo_status, empinfo_work, dept_name, empinfo_hiredate, empinfo_firedate;
	
	/* myinfo */
	private String myinfo_gen, myinfo_addr, myinfo_email, myinfo_tel, myinfo_number, myinfo_helnum;
	
	/* salinfo */
	private int salinfo_salary, salinfo_3month;
	private String salinfo_name, salinfo_bank, salinfo_banknum, salinfo_date;
	
	public int getEmp_no() {
		return emp_no;
	}
	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}
	public int getJik_no() {
		return jik_no;
	}
	public void setJik_no(int jik_no) {
		this.jik_no = jik_no;
	}
	public int getEmpinfo_year() {
		return empinfo_year;
	}
	public void setEmpinfo_year(int empinfo_year) {
		this.empinfo_year = empinfo_year;
	}
	public int getEmpifo_pass() {
		return empifo_pass;
	}
	public void setEmpifo_pass(int empifo_pass) {
		this.empifo_pass = empifo_pass;
	}
	public String getJik_name() {
		return jik_name;
	}
	public void setJik_name(String jik_name) {
		this.jik_name = jik_name;
	}
	public String getEmpinfo_status() {
		return empinfo_status;
	}
	public void setEmpinfo_status(String empinfo_status) {
		this.empinfo_status = empinfo_status;
	}
	public String getEmpinfo_work() {
		return empinfo_work;
	}
	public void setEmpinfo_work(String empinfo_work) {
		this.empinfo_work = empinfo_work;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public String getEmpinfo_hiredate() {
		return empinfo_hiredate;
	}
	public void setEmpinfo_hiredate(String empinfo_hiredate) {
		this.empinfo_hiredate = empinfo_hiredate;
	}
	public String getEmpinfo_firedate() {
		return empinfo_firedate;
	}
	public void setEmpinfo_firedate(String empinfo_firedate) {
		this.empinfo_firedate = empinfo_firedate;
	}
	public String getMyinfo_gen() {
		return myinfo_gen;
	}
	public void setMyinfo_gen(String myinfo_gen) {
		this.myinfo_gen = myinfo_gen;
	}
	public String getMyinfo_addr() {
		return myinfo_addr;
	}
	public void setMyinfo_addr(String myinfo_addr) {
		this.myinfo_addr = myinfo_addr;
	}
	public String getMyinfo_email() {
		return myinfo_email;
	}
	public void setMyinfo_email(String myinfo_email) {
		this.myinfo_email = myinfo_email;
	}
	public String getMyinfo_tel() {
		return myinfo_tel;
	}
	public void setMyinfo_tel(String myinfo_tel) {
		this.myinfo_tel = myinfo_tel;
	}
	public String getMyinfo_number() {
		return myinfo_number;
	}
	public void setMyinfo_number(String myinfo_number) {
		this.myinfo_number = myinfo_number;
	}
	public String getMyinfo_helnum() {
		return myinfo_helnum;
	}
	public void setMyinfo_helnum(String myinfo_helnum) {
		this.myinfo_helnum = myinfo_helnum;
	}
	public int getSalinfo_salary() {
		return salinfo_salary;
	}
	public void setSalinfo_salary(int salinfo_salary) {
		this.salinfo_salary = salinfo_salary;
	}
	public int getSalinfo_3month() {
		return salinfo_3month;
	}
	public void setSalinfo_3month(int salinfo_3month) {
		this.salinfo_3month = salinfo_3month;
	}
	public String getSalinfo_name() {
		return salinfo_name;
	}
	public void setSalinfo_name(String salinfo_name) {
		this.salinfo_name = salinfo_name;
	}
	public String getSalinfo_bank() {
		return salinfo_bank;
	}
	public void setSalinfo_bank(String salinfo_bank) {
		this.salinfo_bank = salinfo_bank;
	}
	public String getSalinfo_banknum() {
		return salinfo_banknum;
	}
	public void setSalinfo_banknum(String salinfo_banknum) {
		this.salinfo_banknum = salinfo_banknum;
	}
	public String getSalinfo_date() {
		return salinfo_date;
	}
	public void setSalinfo_date(String salinfo_date) {
		this.salinfo_date = salinfo_date;
	}
	
	
	
	
	
}
