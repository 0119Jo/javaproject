package pack.login.model;

public class LoginDto {
	String emp_no, empInfo_pass;

	public String getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(String emp_no) {
		this.emp_no = emp_no;
	}

	public String getEmpInfo_pass() {
		return empInfo_pass;
	}

	public void setEmpInfo_pass(String empInfo_pass) {
		this.empInfo_pass = empInfo_pass;
	}
	
	
}
