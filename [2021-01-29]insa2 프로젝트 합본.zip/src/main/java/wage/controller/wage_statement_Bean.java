package wage.controller;

public class wage_statement_Bean {

	private int wage_statement_emp_no, wage_statement_sal, wage_statement_jikpay, wage_statement_overpay,
			wage_statement_specialpay, wage_statement_etcpay, wage_statement_bonus, wage_statement_taxtarget,
			wage_statement_meal, wage_statement_drive, wage_statement_psum, wage_statement_nation, wage_statement_helin,
			wage_statement_carein, wage_statement_empin, wage_statement_intax, wage_statement_lotax,
			wage_statement_beforedel, wage_statement_yearendtax, wage_statement_dsum, wage_statement_salary;
	private String wage_statement_mon, wage_statement_emp_name, wage_statement_dept_name;

	public int getWage_statement_emp_no() {
		return wage_statement_emp_no;
	}

	public void setWage_statement_emp_no(int wage_statement_emp_no) {
		this.wage_statement_emp_no = wage_statement_emp_no;
	}

	public String getWage_statement_emp_name() {
		return wage_statement_emp_name;
	}

	public void setWage_statement_emp_name(String wage_statement_emp_name) {
		this.wage_statement_emp_name = wage_statement_emp_name;
	}

	public String getWage_statement_dept_name() {
		return wage_statement_dept_name;
	}

	public void setWage_statement_dept_name(String wage_statement_dept_name) {
		this.wage_statement_dept_name = wage_statement_dept_name;
	}

	public String getWage_statement_mon() {
		return wage_statement_mon;
	}

	public void setWage_statement_mon(String wage_statement_mon) {
		this.wage_statement_mon = wage_statement_mon;
	}

	public int getWage_statement_sal() {
		return wage_statement_sal;
	}

	public void setWage_statement_sal(int wage_statement_sal) {
		this.wage_statement_sal = wage_statement_sal;
	}

	public int getWage_statement_jikpay() {
		return wage_statement_jikpay;
	}

	public void setWage_statement_jikpay(int wage_statement_jikpay) {
		this.wage_statement_jikpay = wage_statement_jikpay;
	}

	public int getWage_statement_overpay() {
		return wage_statement_overpay;
	}

	public void setWage_statement_overpay(int wage_statement_overpay) {
		this.wage_statement_overpay = wage_statement_overpay;
	}

	public int getWage_statement_specialpay() {
		return wage_statement_specialpay;
	}

	public void setWage_statement_specialpay(int wage_statement_specialpay) {
		this.wage_statement_specialpay = wage_statement_specialpay;
	}

	public int getWage_statement_etcpay() {
		return wage_statement_etcpay;
	}

	public void setWage_statement_etcpay(int wage_statement_etcpay) {
		this.wage_statement_etcpay = wage_statement_etcpay;
	}

	public int getWage_statement_bonus() {
		return wage_statement_bonus;
	}

	public void setWage_statement_bonus(int wage_statement_bonus) {
		this.wage_statement_bonus = wage_statement_bonus;
	}

	public int getWage_statement_taxtarget() {
		return wage_statement_taxtarget;
	}

	public void setWage_statement_taxtarget(int wage_statement_taxtarget) {
		this.wage_statement_taxtarget = wage_statement_taxtarget;
	}

	public int getWage_statement_meal() {
		return wage_statement_meal;
	}

	public void setWage_statement_meal(int wage_statement_meal) {
		this.wage_statement_meal = wage_statement_meal;
	}

	public int getWage_statement_drive() {
		return wage_statement_drive;
	}

	public void setWage_statement_drive(int wage_statement_drive) {
		this.wage_statement_drive = wage_statement_drive;
	}

	public int getWage_statement_psum() {
		return wage_statement_psum;
	}

	public void setWage_statement_psum(int wage_statement_psum) {
		this.wage_statement_psum = wage_statement_psum;
	}

	public int getWage_statement_nation() {
		return wage_statement_nation;
	}

	public void setWage_statement_nation(int wage_statement_nation) {
		this.wage_statement_nation = wage_statement_nation;
	}

	public int getWage_statement_helin() {
		return wage_statement_helin;
	}

	public void setWage_statement_helin(int wage_statement_helin) {
		this.wage_statement_helin = wage_statement_helin;
	}

	public int getWage_statement_carein() {
		return wage_statement_carein;
	}

	public void setWage_statement_carein(int wage_statement_carein) {
		this.wage_statement_carein = wage_statement_carein;
	}

	public int getWage_statement_empin() {
		return wage_statement_empin;
	}

	public void setWage_statement_empin(int wage_statement_empin) {
		this.wage_statement_empin = wage_statement_empin;
	}

	public int getWage_statement_intax() {
		return wage_statement_intax;
	}

	public void setWage_statement_intax(int wage_statement_intax) {
		this.wage_statement_intax = wage_statement_intax;
	}

	public int getWage_statement_lotax() {
		return wage_statement_lotax;
	}

	public void setWage_statement_lotax(int wage_statement_lotax) {
		this.wage_statement_lotax = wage_statement_lotax;
	}

	public int getWage_statement_beforedel() {
		return wage_statement_beforedel;
	}

	public void setWage_statement_beforedel(int wage_statement_beforedel) {
		this.wage_statement_beforedel = wage_statement_beforedel;
	}

	public int getWage_statement_yearendtax() {
		return wage_statement_yearendtax;
	}

	public void setWage_statement_yearendtax(int wage_statement_yearendtax) {
		this.wage_statement_yearendtax = wage_statement_yearendtax;
	}

	public int getWage_statement_dsum() {
		return wage_statement_dsum;
	}

	public void setWage_statement_dsum(int wage_statement_dsum) {
		this.wage_statement_dsum = wage_statement_dsum;
	}

	public int getWage_statement_salary() {
		return wage_statement_salary;
	}

	public void setWage_statement_salary(int wage_statement_salary) {
		this.wage_statement_salary = wage_statement_salary;
	}
}
