package work.model;

public class MtotalDto {
	private int emp_no, mtotal_nomal, mtotal_add, mtotal_del;

	public int getEmp_no() {
		return emp_no;
	}

	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}

	public int getMtotal_nomal() {
		return mtotal_nomal;
	}

	public void setMtotal_nomal(int mtotal_nomal) {
		this.mtotal_nomal = mtotal_nomal;
	}

	public int getMtotal_add() {
		return mtotal_add;
	}

	public void setMtotal_add(int mtotal_add) {
		this.mtotal_add = mtotal_add;
	}

	public int getMtotal_del() {
		return mtotal_del;
	}

	public void setMtotal_del(int mtotal_del) {
		this.mtotal_del = mtotal_del;
	}
	
	
}
