package work.model;

public class WorkDao {

}
