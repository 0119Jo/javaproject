package work.model;

import org.springframework.stereotype.Repository;

@Repository
public class MtotalDao {
	private MtotalDto mtotalDto;
	
	
}
